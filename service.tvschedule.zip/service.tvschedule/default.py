"""
ver 20 - best yet
plot and watched working 
watched & unwatched are updating correctly
Fixed Kodi Virtual Streaming Server Addon
Creates HTTP server that serves episodes based on EPG schedule
Fixed episode filtering logic for user ratings
"""

import xbmc
import xbmcvfs
import xbmcaddon
import json
import time
import threading
import os
import mimetypes
from http.server import HTTPServer, BaseHTTPRequestHandler
from socketserver import ThreadingMixIn
import urllib.parse
import re
import socket
import traceback

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_PATH = ADDON.getAddonInfo("path")
ADDON_DATA = xbmcvfs.translatePath(f"special://userdata/addon_data/{ADDON_ID}/")
M3U_PATH = ADDON_DATA + "schedule.m3u"
XML_PATH = ADDON_DATA + "schedule.xml"
SERVER_PORT = 8765
SCHEDULE_REBUILD_REQUESTED = False

# Ensure addon data directory exists
xbmcvfs.mkdirs(ADDON_DATA)

# Logging functions
def log_info(message):
    xbmc.log(f"[{ADDON_ID}] {message}", xbmc.LOGINFO)

def log_error(message):
    xbmc.log(f"[{ADDON_ID}] ERROR: {message}", xbmc.LOGERROR)

def log_warning(message):
    xbmc.log(f"[{ADDON_ID}] WARNING: {message}", xbmc.LOGWARNING)

# Global variables
SERIES_SCHEDULES = {}
server_instance = None
server_shutdown = threading.Event()

class KodiService:
    """Main service class for proper Kodi integration"""
    
    def __init__(self):
        self.monitor = xbmc.Monitor()

    def run(self):
        """Main service loop"""
        log_info("=== Virtual Streaming Server Service Started ===")
        
        try:
            # Build schedules
            self.build_series_schedules()

            # Force immediate schedule rebuild on startup
            log_info("Forcing schedule rebuild on Kodi startup...")
            self.build_series_schedules()
            self.write_schedule_files()
            log_info("Startup schedule rebuild completed")
            
            if not SERIES_SCHEDULES:
                log_warning("No eligible episodes found for any series")
                return
                
            log_info(f"Found {len(SERIES_SCHEDULES)} series with episodes")
            
            # Write schedule files
            self.write_schedule_files()
            
            # Start streaming server
            if self.start_streaming_server():
                log_info("Streaming server started successfully")
                
                # Main service loop - wait for shutdown and only rebuild when requested
                while not self.monitor.abortRequested():
                    global SCHEDULE_REBUILD_REQUESTED

                    # No automatic rebuilds - only rebuild on Kodi startup
                    rebuild_needed = False

                    if rebuild_needed:
                        SCHEDULE_REBUILD_REQUESTED = False
                        log_info("Schedule rebuild triggered...")
                        old_count = len(SERIES_SCHEDULES)
                        old_schedules = SERIES_SCHEDULES.copy()  # Store old schedules for comparison
                        self.build_series_schedules()
                        new_count = len(SERIES_SCHEDULES)
                    
                        # Always write files if schedules changed or if we have any series
                        schedules_changed = (old_count != new_count or 
                                           old_schedules != SERIES_SCHEDULES or 
                                           SERIES_SCHEDULES)




                        if schedules_changed:
                            self.write_schedule_files()
                            log_info(f"Schedule updated: {old_count} -> {new_count} series, files rewritten")
                        else:
                            log_info("No schedule changes detected")
                   
                    # Check every 30 seconds for shutdown requests only
                    if self.monitor.waitForAbort(30):
                        break

                        
                log_info("Shutdown requested")
            else:
                log_error("Failed to start streaming server")
                
        except Exception as e:
            log_error(f"Service error: {e}")
            log_error(traceback.format_exc())
        finally:
            self.stop_streaming_server()

            # Delete schedule files on shutdown so fresh data is used on next startup
            log_info("Cleaning up schedule files on shutdown...")
            self.cleanup_schedule_files()
            
            log_info("Service stopped")


    def build_series_schedules(self):
        """Build episode schedules for each series"""
        global SERIES_SCHEDULES
    
        log_info("Building/rebuilding series schedules...")
    
        shows = self.get_tv_shows()
        if not shows:
            log_info("No TV shows found in library")
            SERIES_SCHEDULES = {}
            return

        # Force fresh episode data by clearing any potential cache
        log_info(f"Processing {len(shows)} TV shows for schedule rebuild")
     
        # Store current time positions for existing schedules
        # BUT only for episodes that are still eligible (not watched)
        current_positions = {}
        current_time = int(time.time())
    
        for series_name, series_info in SERIES_SCHEDULES.items():
            for episode in series_info['episodes']:
                if episode['start_time'] <= current_time < episode['end_time']:
                    # Store the current position but we'll validate eligibility later
                    current_positions[series_name] = {
                        'season': episode['season'],
                        'episode': episode['episode'],
                        'elapsed': current_time - episode['start_time'],
                        'title': episode.get('title', 'Unknown'),
                        'was_current': True
                    }
                    log_info(f"Currently playing: {episode['title']} in {series_name}")
                    break

        # Force clear any cached episode data
        log_info("Forcing library data refresh...")
    
        # Clear and rebuild schedules
        SERIES_SCHEDULES = {}
        base_time = current_time
    
        for show in shows:
            series_title = show.get("label", "Unknown Series")
            genres = show.get("genre", ["Unknown"])
            art_data = show.get("art", {})
            poster_url = art_data.get("poster", "") or art_data.get("tvshow.poster", "") or show.get("thumbnail", "")
            # Debug poster information
            art_data = show.get("art", {})
            thumbnail = show.get("thumbnail", "")
            fanart = show.get("fanart", "")
            log_info(f"=== Series: {series_title} ===")
            log_info(f"  Full show data keys: {list(show.keys())}")
            log_info(f"  Art data: {art_data}")
            log_info(f"  Thumbnail: {thumbnail}")
            log_info(f"  Fanart: {fanart}")
            log_info(f"  Final poster URL: {poster_url}")
            log_info("================================")
        
            # Always get fresh episode data to check current watch status
            episodes = self.get_episodes(show["tvshowid"])
            if not episodes:
                continue
         
            # Filter and validate episodes - FIXED LOGIC
            eligible_episodes = []
            current_time = int(time.time())
            
            for ep in episodes:
                # Skip watched episodes - BUT keep currently playing episodes even if marked watched
                playcount = ep.get("playcount", 0)
                episode_title = ep.get('title', 'Unknown')
                
                # Check if this episode is currently being streamed
                is_currently_playing = False
                if series_title in SERIES_SCHEDULES:
                    for existing_ep in SERIES_SCHEDULES[series_title]['episodes']:
                        if (existing_ep.get('title') == episode_title and 
                            existing_ep['start_time'] <= current_time < existing_ep['end_time']):
                            is_currently_playing = True
                            log_info(f"Episode '{episode_title}' is currently playing - keeping in schedule even if watched")
                            break
                
                if playcount > 0 and not is_currently_playing:
                    log_info(f"FILTERING OUT watched episode: {episode_title} (playcount: {playcount}) for series: {series_title}")
                    continue
                elif playcount > 0 and is_currently_playing:
                    log_info(f"KEEPING currently playing watched episode: {episode_title} (playcount: {playcount})")
            
                # Check user rating - Must be > 7 and not None/0
                userrating = ep.get("userrating")
                if userrating is None or userrating == 0:
                    log_info(f"Skipping episode with no rating: {ep.get('title', 'Unknown')} (userrating: {userrating})")
                    continue
                    
                if userrating <= 7:
                    log_info(f"Skipping low-rated episode: {ep.get('title', 'Unknown')} (userrating: {userrating})")
                    continue
            
                # Verify file exists and is accessible
                file_path = ep.get("file", "")
                if not file_path or not self.verify_file_access(file_path):
                    log_warning(f"Skipping inaccessible file: {ep.get('title', 'Unknown')} ({file_path})")
                    continue
            
                # Debug runtime information
                kodi_runtime = ep.get("runtime", 0)
                streamdetails = ep.get("streamdetails", {})
                video_details = streamdetails.get("video", [])
                stream_duration = video_details[0].get("duration", 0) if video_details else 0
                
                log_info(f"Runtime debug for '{ep.get('title', 'Unknown')}': kodi_runtime={kodi_runtime}, stream_duration={stream_duration}")
                
                # Use stream duration if available, otherwise use kodi runtime
                actual_runtime = stream_duration if stream_duration > 0 else kodi_runtime
                
                ep_data = {
                    "season": ep.get("season", 0),
                    "episode": ep.get("episode", 0),
                    "title": ep.get("title", "Unknown Title"),
                    "file": file_path,
                    "runtime": self.get_episode_duration(actual_runtime),
                    "userrating": userrating,
                    "plot": ep.get("plot", "No description available")
                }
                eligible_episodes.append(ep_data)
                log_info(f"KEEPING episode: {ep_data['title']} (S{ep_data['season']:02d}E{ep_data['episode']:02d}, rating: {userrating}, runtime: {ep_data['runtime']} min)")
        
            if not eligible_episodes:
                log_info(f"No eligible episodes for {series_title} - removing from schedule")
                continue
        
            # Sort episodes by season and episode number
            #eligible_episodes.sort(key=lambda e: (e["season"], e["episode"]))   # remmed this line so I can sort randomly
            
            # Sort episodes randomly for variety, but only if this is a new series
            # or if the episode list has changed significantly
            import random
            
            # Check if this series existed before and if episodes are similar
            if series_title in current_positions:
                # Series existed before - try to maintain order if possible
                # Only re-shuffle if the episode count changed significantly
                old_episode_count = len([ep for ep in SERIES_SCHEDULES.get(series_title, {}).get('episodes', [])])
                new_episode_count = len(eligible_episodes)
                
                if abs(old_episode_count - new_episode_count) <= 1:
                    # Episode count is similar, try to maintain existing order
                    # Sort by season/episode to maintain consistency
                    eligible_episodes.sort(key=lambda e: (e["season"], e["episode"]))
                else:
                    # Significant change in episodes, re-shuffle
                    random.shuffle(eligible_episodes)
            else:
                # New series, randomize the initial order
                random.shuffle(eligible_episodes)
        
            # Assign time slots
            schedule_start_time = base_time
        
            # If we have a current position for this series, try to maintain it
            # BUT only if that episode is still in the eligible list AND was actually current
            if series_title in current_positions and current_positions[series_title].get('was_current', False):
                pos = current_positions[series_title]
                log_info(f"Checking if previous episode '{pos['title']}' (S{pos['season']:02d}E{pos['episode']:02d}) is still eligible for {series_title}")
                # Find the episode that was playing
                found_previous_episode = False
                for i, episode in enumerate(eligible_episodes):
                    if episode['season'] == pos['season'] and episode['episode'] == pos['episode']:
                        found_previous_episode = True
                        log_info(f"Previous episode still eligible, maintaining position")

                        # Start from this episode, accounting for elapsed time
                        remaining_time = (episode['runtime'] * 60) - pos['elapsed']
                        if remaining_time > 60:  # If more than 1 minute left
                            log_info(f"Continuing from previous position with {remaining_time} seconds remaining")
                            schedule_start_time = current_time
                            episode['start_time'] = current_time
                            episode['end_time'] = current_time + remaining_time
                        
                            # Schedule remaining episodes
                            next_start = episode['end_time']
                            for j in range(i + 1, len(eligible_episodes)):
                                duration_seconds = eligible_episodes[j]['runtime'] * 60
                                eligible_episodes[j]['start_time'] = next_start
                                eligible_episodes[j]['end_time'] = next_start + duration_seconds
                                next_start += duration_seconds
                                log_info(f"Scheduled episode {eligible_episodes[j]['title']} from {eligible_episodes[j]['start_time']} to {eligible_episodes[j]['end_time']}")
                        
                            # Schedule episodes before current one (loop back)
                            for j in range(i):
                                duration_seconds = eligible_episodes[j]['runtime'] * 60
                                eligible_episodes[j]['start_time'] = next_start
                                eligible_episodes[j]['end_time'] = next_start + duration_seconds
                                next_start += duration_seconds
                                log_info(f"Scheduled loop episode {eligible_episodes[j]['title']} from {eligible_episodes[j]['start_time']} to {eligible_episodes[j]['end_time']}")
                        
                        break
                
                if not found_previous_episode:
                    log_info(f"Previous episode '{pos['title']}' no longer eligible (likely watched), starting fresh with first available episode immediately")
                    # Episode was filtered out (watched), start fresh from current time with first episode
                    current_time_slot = current_time  # Start immediately, not from base_time
                    for episode in eligible_episodes:
                        duration_seconds = episode['runtime'] * 60
                        episode['start_time'] = current_time_slot
                        episode['end_time'] = current_time_slot + duration_seconds
                        current_time_slot += duration_seconds
                        log_info(f"Fresh schedule - episode {episode['title']} from {episode['start_time']} to {episode['end_time']}")
            else:
                # New series or no previous position - check if series had a previous schedule
                # and calculate where it should be now based on original timing
                current_time_slot = schedule_start_time
                
                # Check if this series had episodes in the previous schedule
                # If so, calculate where we should be now based on elapsed time
                total_series_duration = sum(ep['runtime'] * 60 for ep in eligible_episodes)
                if total_series_duration > 0:
                    # Calculate how much time has passed since base_time
                    elapsed_since_start = current_time - base_time
                    # Find position within the series loop
                    position_in_loop = elapsed_since_start % total_series_duration
                    
                    # Find which episode should be playing and at what offset
                    cumulative_time = 0
                    found_current = False
                    
                    for i, episode in enumerate(eligible_episodes):
                        episode_duration = episode['runtime'] * 60
                        if not found_current and cumulative_time + episode_duration > position_in_loop:
                            # This episode should be currently playing
                            episode_offset = position_in_loop - cumulative_time
                            remaining_time = episode_duration - episode_offset
                            
                            if remaining_time > 60:  # If more than 1 minute left
                                log_info(f"Calculated position for {series_title}: {episode['title']} at {episode_offset}s offset")
                                # Start this episode from the calculated position
                                episode['start_time'] = current_time
                                episode['end_time'] = current_time + remaining_time
                                
                                # Schedule remaining episodes
                                next_start = episode['end_time']
                                for j in range(i + 1, len(eligible_episodes)):
                                    duration_seconds = eligible_episodes[j]['runtime'] * 60
                                    eligible_episodes[j]['start_time'] = next_start
                                    eligible_episodes[j]['end_time'] = next_start + duration_seconds
                                    next_start += duration_seconds
                                
                                # Schedule episodes before current one (loop back)
                                for j in range(i):
                                    duration_seconds = eligible_episodes[j]['runtime'] * 60
                                    eligible_episodes[j]['start_time'] = next_start
                                    eligible_episodes[j]['end_time'] = next_start + duration_seconds
                                    next_start += duration_seconds
                                
                                found_current = True
                                break
                        
                        cumulative_time += episode_duration
                    
                    # If we didn't find a current episode or remaining time too short, start fresh
                    if not found_current:
                        current_time_slot = current_time
                        for episode in eligible_episodes:
                            duration_seconds = episode['runtime'] * 60
                            episode['start_time'] = current_time_slot
                            episode['end_time'] = current_time_slot + duration_seconds
                            current_time_slot += duration_seconds
                else:
                    # Fallback to normal scheduling
                    for episode in eligible_episodes:
                        duration_seconds = episode['runtime'] * 60
                        episode['start_time'] = current_time_slot
                        episode['end_time'] = current_time_slot + duration_seconds
                        current_time_slot += duration_seconds
        
            SERIES_SCHEDULES[series_title] = {
                'genres': genres,
                'episodes': eligible_episodes,
                'poster': poster_url
            }
        
            log_info(f"Scheduled {len(eligible_episodes)} episodes for {series_title}")
    
        # If no series have eligible episodes, ensure files reflect this
        if not SERIES_SCHEDULES:
            log_info("No series with eligible episodes - clearing schedule files")
    
    
    def cleanup_schedule_files(self):
        """Delete existing M3U and XML schedule files"""
        try:
            # Delete M3U file if it exists
            if xbmcvfs.exists(M3U_PATH):
                if xbmcvfs.delete(M3U_PATH):
                    log_info(f"Deleted existing M3U file: {M3U_PATH}")
                else:
                    log_warning(f"Failed to delete M3U file: {M3U_PATH}")
            else:
                log_info("No existing M3U file to delete")
        
            # Delete XML file if it exists
            if xbmcvfs.exists(XML_PATH):
                if xbmcvfs.delete(XML_PATH):
                    log_info(f"Deleted existing XML file: {XML_PATH}")
                else:
                    log_warning(f"Failed to delete XML file: {XML_PATH}")
            else:
                log_info("No existing XML file to delete")
            
        except Exception as e:
            log_error(f"Error during file cleanup: {e}")


    def get_tv_shows(self):
        """Get TV shows from Kodi library"""
        try:
            request = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "VideoLibrary.GetTVShows",
                "params": {"properties": ["genre", "art", "thumbnail", "fanart"]}
            }
            response = xbmc.executeJSONRPC(json.dumps(request))
            result = json.loads(response)
            
            if "error" in result:
                log_error(f"JSON-RPC error: {result['error']}")
                return []
                
            return result.get("result", {}).get("tvshows", [])
        except Exception as e:
            log_error(f"Error getting TV shows: {e}")
            return []
    
    def get_episodes(self, tvshowid):
        """Get episodes for a TV show"""
        try:
            request = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "VideoLibrary.GetEpisodes",
                "params": {
                    "tvshowid": tvshowid,
                    "properties": ["season", "episode", "playcount", "file", "title", "rating", "userrating", "runtime", "plot", "streamdetails"]
                }
            }
            response = xbmc.executeJSONRPC(json.dumps(request))
            result = json.loads(response)
            
            if "error" in result:
                log_error(f"JSON-RPC error: {result['error']}")
                return []
                
            return result.get("result", {}).get("episodes", [])
        except Exception as e:
            log_error(f"Error getting episodes: {e}")
            return []
    
    def get_episode_duration(self, runtime):
        """Calculate episode duration in minutes using actual runtime"""
        if not runtime:
            log_info(f"No runtime provided, using 30 minute default")
            return 30  # Default fallback
        
        # Runtime from Kodi is already in seconds, so convert to minutes
        minutes = runtime // 60
        # Add extra minute if there are remaining seconds to avoid cutting off
        if runtime % 60 > 0:
            minutes += 1
        # Ensure minimum duration of 1 minute
        final_minutes = max(1, minutes)
        
        log_info(f"Runtime calculation: {runtime} seconds -> {minutes} minutes -> {final_minutes} final minutes")
        return final_minutes
    
    def verify_file_access(self, file_path):
        """Verify file exists and is accessible"""
        try:
            file_obj = xbmcvfs.File(file_path)
            size = file_obj.size()
            file_obj.close()
            return size > 0
        except:
            return False
    
    def write_schedule_files(self):
        """Write M3U and XMLTV files"""
        try:
            # Write M3U playlist with cache-busting timestamp
            current_timestamp = int(time.time())
            with xbmcvfs.File(M3U_PATH, "w") as f:
                f.write("#EXTM3U\n")
                f.write(f"#EXT-X-VERSION:3\n")
                f.write(f"#PLAYLIST-UPDATED:{current_timestamp}\n")
                
                if not SERIES_SCHEDULES:
                    log_info("Writing empty M3U file - no eligible series")

                
                for series_name in sorted(SERIES_SCHEDULES.keys()):
                    series_info = SERIES_SCHEDULES[series_name]
                    primary_genre = series_info['genres'][0] if series_info['genres'] else "Unknown"
                    
                    # Add cache-busting parameter to stream URL
                    stream_url = f"http://127.0.0.1:{SERVER_PORT}/{urllib.parse.quote(series_name)}?t={current_timestamp}"
                    f.write(f"#EXTINF:-1 tvg-id=\"{self.sanitize(series_name)}\" tvg-name=\"{self.sanitize(series_name)}\" group-title=\"{self.sanitize(primary_genre)}\",{self.sanitize(series_name)}\n")
                    f.write(f"{stream_url}\n")
            
            # Write XMLTV EPG
            with xbmcvfs.File(XML_PATH, "w") as xml_file:
                xml_file.write('<?xml version="1.0" encoding="UTF-8"?>\n')
                xml_file.write('<!DOCTYPE tv SYSTEM "xmltv.dtd">\n')
                xml_file.write('<tv>\n')
                
                # Write channels
                if not SERIES_SCHEDULES:
                    log_info("Writing empty XMLTV file - no eligible series")
                
                for series_name in sorted(SERIES_SCHEDULES.keys()):
                    xml_file.write(f'  <channel id="{self.sanitize(series_name)}">\n')
                    xml_file.write(f'    <display-name>{self.sanitize(series_name)}</display-name>\n')
                    series_info = SERIES_SCHEDULES[series_name]
                    poster_url = series_info.get('poster', '')
                    log_info(f"Writing XML for {series_name}, poster_url: '{poster_url}'")
                    if poster_url:
                        # Create HTTP URL for poster served by our server
                        http_poster_url = f"http://127.0.0.1:{SERVER_PORT}/poster/{urllib.parse.quote(series_name)}"
                        xml_file.write(f'    <icon src="{http_poster_url}" />\n')
                        log_info(f"Added icon tag with URL: {http_poster_url}")
                    else:
                        log_info(f"No poster URL found for {series_name}")
                    xml_file.write(f'  </channel>\n')
                
                # Write programs
                for series_name in sorted(SERIES_SCHEDULES.keys()):
                    series_info = SERIES_SCHEDULES[series_name]
                    primary_genre = series_info['genres'][0] if series_info['genres'] else "Unknown"
                    
                    for episode in series_info['episodes']:
                        start_str = time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(episode['start_time']))
                        stop_str = time.strftime("%Y%m%d%H%M%S +0000", time.gmtime(episode['end_time']))
                        
                        title = f"{series_name} - {episode['title']}"
                        desc = f"S{episode.get('season', 0):02d}E{episode.get('episode', 0):02d}\nRating: {episode.get('userrating', 'N/A')}\n{episode.get('plot', 'No description available')}"
                        
                        # Get poster URL for this programme
                        poster_url = series_info.get('poster', '')
                        programme_icon = ""
                        if poster_url:
                            programme_icon = f"http://127.0.0.1:{SERVER_PORT}/poster/{urllib.parse.quote(series_name)}"
                        
                        xml_file.write(f'  <programme start="{start_str}" stop="{stop_str}" channel="{self.sanitize(series_name)}">\n')
                        xml_file.write(f'    <title lang="en">{self.sanitize(title)}</title>\n')
                        xml_file.write(f'    <category lang="en">{self.sanitize(primary_genre)}</category>\n')
                        xml_file.write(f'    <desc lang="en">{self.sanitize(desc)}</desc>\n')
                        if programme_icon:
                            xml_file.write(f'    <icon src="{programme_icon}" />\n')
                        xml_file.write(f'  </programme>\n')
                
                xml_file.write('</tv>\n')
            
            log_info(f"Schedule files written: {M3U_PATH}, {XML_PATH}")
            
        except Exception as e:
            log_error(f"Failed to write schedule files: {e}")
    
    def sanitize(self, text):
        """Sanitize text for XML"""
        return (text.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&apos;"))
    
    def start_streaming_server(self):
        """Start the HTTP streaming server"""
        global server_instance, SERVER_PORT
        
        try:
            # Find available port
            for port in range(SERVER_PORT, SERVER_PORT + 10):
                if self.check_port_available(port):
                    SERVER_PORT = port
                    break
            else:
                log_error("No available ports found")
                return False
            
            # Create and start server
            server_instance = ThreadedHTTPServer(('0.0.0.0', SERVER_PORT), StreamingHandler)
            server_instance.timeout = 1.0  # For responsive shutdown
            
            # Start server in background thread
            server_thread = threading.Thread(target=self.run_server, daemon=False)
            server_thread.start()
            
            log_info(f"HTTP server started on port {SERVER_PORT}")
            return True
            
        except Exception as e:
            log_error(f"Failed to start server: {e}")
            return False
    
    def check_port_available(self, port):
        """Check if port is available"""
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(1)
            result = sock.connect_ex(('127.0.0.1', port))
            sock.close()
            return result != 0
        except:
            return False
    
    def run_server(self):
        """Run the HTTP server"""
        global server_instance
        
        try:
            while not server_shutdown.is_set() and server_instance:
                server_instance.handle_request()
        except Exception as e:
            if not server_shutdown.is_set():
                log_error(f"Server error: {e}")
        finally:
            log_info("Server thread ended")
    
    def stop_streaming_server(self):
        """Stop the HTTP streaming server"""
        global server_instance
        
        try:
            server_shutdown.set()
            
            if server_instance:
                server_instance.server_close()
                server_instance = None
                
            log_info("Streaming server stopped")
            
        except Exception as e:
            log_error(f"Error stopping server: {e}")


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Multi-threaded HTTP server"""
    daemon_threads = True
    allow_reuse_address = True


class StreamingHandler(BaseHTTPRequestHandler):
    """HTTP request handler for video streaming"""
    
    def log_message(self, format, *args):
        """Override default logging"""
        log_info(f"HTTP: {format % args}")
    
    def do_OPTIONS(self):
        """Handle OPTIONS requests for CORS"""
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Range')
        self.end_headers()
    
    def do_HEAD(self):
        """Handle HEAD requests"""
        try:
            series_name = self.get_series_name()
            if not series_name:
                return
                
            current_episode = self.get_current_episode(series_name)
            if not current_episode:
                return
            
            # Allow HEAD requests to proceed - watch status will be handled during actual streaming
                
            self.send_file_headers(current_episode['file'])
            
        except Exception as e:
            log_error(f"HEAD request error: {e}")
            self.send_error(500, "Internal server error")

    # immediately marks a video as watched
    def do_GET(self):
        """Handle GET requests"""
        try:
            # Check if this is a poster request
            if self.path.startswith('/poster/'):
                log_info(f"Poster request received: {self.path}")
                self.serve_poster()
                return
                
            series_name = self.get_series_name()
            if not series_name:
                return
                
            current_episode = self.get_current_episode(series_name)
            if not current_episode:
                return
            
            # Only check if episode is watched if it was marked watched by our own streaming process
            # Don't block playback based on existing watch status
                
            log_info(f"Streaming: {current_episode['title']} ({current_episode['file']}) [Rating: {current_episode.get('userrating', 'N/A')}]")
            
            # Mark episode as watched when streaming starts
            # self.mark_episode_watched(current_episode)          # this code marks an episode as watched immediately after starting
            
            self.stream_file(current_episode['file'], current_episode)
            
        except Exception as e:
            log_error(f"GET request error: {e}")
            self.send_error(500, "Internal server error")
    
    def get_series_name(self):
        """Extract series name from URL path"""
        try:
            parsed_path = urllib.parse.urlparse(self.path)
            series_name = urllib.parse.unquote(parsed_path.path.strip('/'))
            
            if not series_name or series_name not in SERIES_SCHEDULES:
                log_error(f"Series not found: '{series_name}'")
                self.send_error(404, "Series not found")
                return None
                
            return series_name
        except Exception as e:
            log_error(f"Error parsing series name: {e}")
            self.send_error(400, "Bad request")
            return None
    
    def get_current_episode(self, series_name):
        """Get the current episode for a series based on schedule"""
        try:
            schedule = SERIES_SCHEDULES[series_name]
            current_time = int(time.time())
            
            # Check if schedule is empty (all episodes watched)
            if not schedule['episodes']:
                log_info(f"No eligible episodes remaining for {series_name}")
                self.send_error(404, "No episodes available - all watched")
                return None
            
            # Find current episode
            for episode_data in schedule['episodes']:
                if episode_data['start_time'] <= current_time < episode_data['end_time']:
                    return episode_data
            
            # If no current episode, find next available or loop back
            if schedule['episodes']:
                # Find the next episode that should be playing
                for episode_data in schedule['episodes']:
                    if current_time < episode_data['end_time']:
                        # If we're past the start time, this is the current episode
                        if current_time >= episode_data['start_time']:
                            return episode_data
                        # If we're before the start time, start it immediately for continuous playback
                        else:
                            log_info(f"Next episode was scheduled for {episode_data['start_time']}, starting immediately at {current_time}")
                            # Adjust start time to current time for immediate playback
                            episode_data['start_time'] = current_time
                            # Adjust end time to maintain proper duration
                            duration = episode_data['runtime'] * 60
                            episode_data['end_time'] = current_time + duration
                            return episode_data
                
                # If all episodes have ended, loop back to first episode
                # Calculate loop position for continuous playback
                last_episode = schedule['episodes'][-1]
                if current_time >= last_episode['end_time']:
                    # Start the cycle over
                    first_episode = schedule['episodes'][0]
                    log_info("All episodes finished, looping back to first episode")
                    return first_episode
                
                # Fallback to first episode
                return schedule['episodes'][0]
            
            log_error(f"No episodes available for {series_name}")
            self.send_error(404, "No episodes available")
            return None
            
        except Exception as e:
            log_error(f"Error getting current episode: {e}")
            self.send_error(500, "Internal server error")
            return None
    
    def send_file_headers(self, file_path):
        """Send headers for file without content"""
        try:
            # Get file size
            file_obj = xbmcvfs.File(file_path)
            file_size = file_obj.size()
            file_obj.close()
            
            if file_size <= 0:
                self.send_error(404, "File not found")
                return
            
            # Get MIME type
            mime_type = self.get_mime_type(file_path)
            
            # Send headers
            self.send_response(200)
            self.send_header('Content-Type', mime_type)
            self.send_header('Content-Length', str(file_size))
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
        except Exception as e:
            log_error(f"Error sending file headers: {e}")
            self.send_error(404, "File not found")
    
    def stream_file(self, file_path, episode_data=None):
        """Stream video file with range support"""
        file_obj = None
        try:
            # Open file
            file_obj = xbmcvfs.File(file_path, 'rb')
            file_size = file_obj.size()
            
            if file_size <= 0:
                file_obj.close()
                self.send_error(404, "File not found")
                return
            
            # Parse range header
            range_header = self.headers.get('Range')
            start = 0
            end = file_size - 1
            
            if range_header:
                range_match = re.match(r'bytes=(\d*)-(\d*)', range_header)
                if range_match:
                    start_str, end_str = range_match.groups()
                    if start_str:
                        start = int(start_str)
                    if end_str:
                        end = int(end_str)
                    
                    # Validate range
                    start = max(0, min(start, file_size - 1))
                    end = max(start, min(end, file_size - 1))
            
            # Calculate content length for this range
            content_length = end - start + 1
            
            # Don't mark as watched for small range requests (likely seeking/buffering)
            is_small_range = content_length < (file_size * 0.1)  # Less than 10% of file
            log_info(f"Range request: {start}-{end}/{file_size} (content_length: {content_length}, is_small_range: {is_small_range})")
            
            # Send response headers
            if range_header:
                self.send_response(206)  # Partial Content
                self.send_header('Content-Range', f'bytes {start}-{end}/{file_size}')
            else:
                self.send_response(200)
            
            self.send_header('Content-Type', self.get_mime_type(file_path))
            self.send_header('Content-Length', str(content_length))
            self.send_header('Accept-Ranges', 'bytes')
            self.send_header('Cache-Control', 'no-cache, no-store, must-revalidate')
            self.send_header('Pragma', 'no-cache')
            self.send_header('Expires', '0')
            self.send_header('Access-Control-Allow-Origin', '*')
            self.end_headers()
            
            # Seek to start position
            if start > 0:
                file_obj.seek(start)
            
            # Stream file content
            bytes_sent = 0
            chunk_size = 64 * 1024  # 64KB chunks
            # Only calculate watch threshold for large ranges (likely full playback)
            watch_threshold = int(file_size * 0.8) if not is_small_range else file_size + 1  # Set impossible threshold for small ranges
            marked_watched = False
            log_info(f"Streaming started - File size: {file_size}, Content length: {content_length}, Watch threshold: {watch_threshold} bytes")
            log_info(f"Episode: {episode_data.get('title', 'Unknown') if episode_data else 'No episode data'}")
            
            while bytes_sent < content_length and not server_shutdown.is_set():
                remaining = content_length - bytes_sent
                read_size = min(chunk_size, remaining)
                
                chunk = file_obj.readBytes(read_size)
                if not chunk:
                    log_info("No more data to read from file")
                    break
                
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                    bytes_sent += len(chunk)
                    
                    # Log progress every 10MB for debugging
                    if bytes_sent % (10 * 1024 * 1024) == 0 or bytes_sent == len(chunk):  # Every 10MB or first chunk
                        percentage = (bytes_sent / content_length) * 100 if content_length > 0 else 0
                        log_info(f"Streaming progress: {bytes_sent}/{content_length} bytes ({percentage:.1f}%)")
                    
                    # Only mark as watched when 80% of ENTIRE FILE has been streamed (not just this range)
                    total_bytes_position = start + bytes_sent
                    if not marked_watched and not is_small_range and total_bytes_position >= watch_threshold and file_size > 0:
                        marked_watched = True
                        percentage = (bytes_sent / content_length) * 100
                        file_percentage = (total_bytes_position / file_size) * 100
                        log_info(f"*** 80% THRESHOLD REACHED *** Total position in file: {total_bytes_position}/{file_size} ({file_percentage:.1f}%)")
                        # Actually mark the episode as watched in Kodi
                        if episode_data:
                            log_info(f"*** MARKING EPISODE AS WATCHED: {episode_data.get('title', 'Unknown')} ***")
                            self.mark_episode_watched(episode_data)
                            log_info("*** EPISODE MARKED AS WATCHED SUCCESSFULLY ***")
                        else:
                            log_error("*** NO EPISODE_DATA AVAILABLE TO MARK AS WATCHED ***")
                        # Note: Schedule rebuild will happen on next Kodi startup
                        
                except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
                    log_info("Client disconnected during streaming")
                    # Don't mark as watched if client disconnected early
                    if not marked_watched:
                        log_info("Client disconnected before 80% threshold - not marking as watched")
                    break
                except Exception as e:
                    log_error(f"Streaming error: {e}")
                    break
            
            log_info(f"Streaming finished - Streamed {bytes_sent}/{content_length} bytes ({(bytes_sent/content_length)*100:.1f}%) - Marked watched: {marked_watched}")
            
        except Exception as e:
            log_error(f"File streaming error: {e}")
            self.send_error(500, "Internal server error")
        finally:
            if file_obj:
                try:
                    file_obj.close()
                except:
                    pass
    
    def get_mime_type(self, file_path):
        """Get MIME type for file"""
        mime_type, _ = mimetypes.guess_type(file_path)
        if mime_type:
            return mime_type
        
        # Fallback based on extension
        ext = os.path.splitext(file_path)[1].lower()
        mime_types = {
            '.mp4': 'video/mp4',
            '.m4v': 'video/mp4',
            '.mkv': 'video/x-matroska',
            '.avi': 'video/x-msvideo',
            '.mov': 'video/quicktime',
            '.wmv': 'video/x-ms-wmv',
            '.flv': 'video/x-flv',
            '.webm': 'video/webm'
        }
        return mime_types.get(ext, 'video/mp4')
    
    def mark_episode_watched(self, episode_data):
        """Mark an episode as watched in the Kodi library and trigger schedule rebuild"""
        try:
            # Find the episode ID by matching file path
            episode_id = self.find_episode_id(episode_data['file'])
            if episode_id:
                request = {
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "VideoLibrary.SetEpisodeDetails",
                    "params": {
                        "episodeid": episode_id,
                        "playcount": 1
                    }
                }
                response = xbmc.executeJSONRPC(json.dumps(request))
                result = json.loads(response)
            
                if "error" in result:
                    log_error(f"Error marking episode as watched: {result['error']}")
                else:
                    log_info(f"Marked episode as watched: {episode_data['title']}")
                



                    # Schedule will be rebuilt on next Kodi startup
                    log_info("Episode marked as watched - schedule will rebuild on next Kodi startup")



            else:
                log_warning(f"Could not find episode ID for: {episode_data['title']}")

        except Exception as e:
            log_error(f"Error marking episode as watched: {e}")                




    def is_episode_watched(self, file_path):
        """Check if episode is watched by querying fresh data from Kodi"""
        try:
            request = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "VideoLibrary.GetEpisodes",
                "params": {
                    "properties": ["file", "playcount"]
                }
            }
            response = xbmc.executeJSONRPC(json.dumps(request))
            result = json.loads(response)
            
            if "error" not in result and "result" in result:
                episodes = result["result"].get("episodes", [])
                for ep in episodes:
                    if ep.get("file") == file_path:
                        playcount = ep.get("playcount", 0)
                        return playcount > 0
            
            return False
            
        except Exception as e:
            log_error(f"Error checking if episode is watched: {e}")
            return False






    
    def find_episode_id(self, file_path):
        """Find episode ID by file path"""
        try:
            # Get all episodes and find matching file path
            request = {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "VideoLibrary.GetEpisodes",
                "params": {
                    "properties": ["file"]
                }
            }
            response = xbmc.executeJSONRPC(json.dumps(request))
            result = json.loads(response)
            
            if "error" not in result and "result" in result:
                episodes = result["result"].get("episodes", [])
                for ep in episodes:
                    if ep.get("file") == file_path:
                        return ep.get("episodeid")
            
            return None
            
        except Exception as e:
            log_error(f"Error finding episode ID: {e}")
            return None

    def serve_poster(self):
        """Serve poster image for a series"""
        try:
            # Extract series name from /poster/series_name
            path_parts = self.path.split('/')
            if len(path_parts) < 3:
                self.send_error(404, "Invalid poster path")
                return
                
            series_name = urllib.parse.unquote(path_parts[2])
            
            if series_name not in SERIES_SCHEDULES:
                self.send_error(404, "Series not found")
                return
                
            poster_path = SERIES_SCHEDULES[series_name].get('poster', '')
            log_info(f"Poster request for {series_name}, path: '{poster_path}'")
            if not poster_path:
                log_warning(f"No poster path found for {series_name}")
                self.send_error(404, "No poster available")
                return
                
            # Convert Kodi's image:// URL to actual file path if needed
            if poster_path.startswith('image://'):
                try:
                    # Remove 'image://' prefix and trailing '/'
                    encoded_path = poster_path[8:].rstrip('/')
                    # URL decode the path
                    decoded_path = urllib.parse.unquote(encoded_path)
                    poster_path = decoded_path
                    log_info(f"Decoded Kodi image URL: {poster_path} -> {decoded_path}")
                except Exception as e:
                    log_error(f"Failed to decode Kodi image URL {poster_path}: {e}")
                    self.send_error(404, "Invalid image URL")
                    return
            
            # Try to read and serve the poster file
            try:
                log_info(f"Attempting to open poster file: {poster_path}")
                file_obj = xbmcvfs.File(poster_path, 'rb')
                file_size = file_obj.size()
                log_info(f"Poster file size: {file_size}")
                
                if file_size <= 0:
                    file_obj.close()
                    log_warning(f"Poster file has zero size: {poster_path}")
                    self.send_error(404, "Poster file not found")
                    return
                
                # Determine content type based on file extension
                ext = os.path.splitext(poster_path)[1].lower()
                content_type = {
                    '.jpg': 'image/jpeg',
                    '.jpeg': 'image/jpeg', 
                    '.png': 'image/png',
                    '.gif': 'image/gif',
                    '.webp': 'image/webp'
                }.get(ext, 'image/jpeg')
                
                # Send headers
                self.send_response(200)
                self.send_header('Content-Type', content_type)
                self.send_header('Content-Length', str(file_size))
                self.send_header('Cache-Control', 'public, max-age=3600')
                self.send_header('Access-Control-Allow-Origin', '*')
                self.end_headers()
                
                # Stream the poster file
                while True:
                    chunk = file_obj.readBytes(8192)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                
                file_obj.close()
                log_info(f"Served poster for {series_name}")
                
            except Exception as e:
                log_error(f"Error reading poster file {poster_path}: {e}")
                log_error(f"Exception details: {traceback.format_exc()}")
                self.send_error(404, "Poster file not accessible")
                
        except Exception as e:
            log_error(f"Error serving poster: {e}")
            self.send_error(500, "Internal server error")

def main():
    """Main entry point"""
    try:
        service = KodiService()
        service.run()
    except Exception as e:
        log_error(f"Service startup error: {e}")
        log_error(traceback.format_exc())


if __name__ == "__main__":
    main()